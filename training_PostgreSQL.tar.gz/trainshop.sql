--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.10
-- Dumped by pg_dump version 9.5.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: laptop; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE laptop (
    code integer NOT NULL,
    model text,
    speed integer,
    ram integer,
    hd integer,
    screen numeric,
    price numeric,
    CONSTRAINT laptop_hd_check CHECK ((hd > 0)),
    CONSTRAINT laptop_price_check CHECK ((price > (0)::numeric)),
    CONSTRAINT laptop_ram_check CHECK ((ram > 0)),
    CONSTRAINT laptop_screen_check CHECK ((screen > (0)::numeric)),
    CONSTRAINT laptop_speed_check CHECK ((speed > 0))
);


--
-- Name: laptop_code_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE laptop_code_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: laptop_code_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE laptop_code_seq OWNED BY laptop.code;


--
-- Name: pc; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE pc (
    code integer NOT NULL,
    model text,
    speed integer,
    ram integer,
    hd integer,
    cd text,
    price numeric,
    CONSTRAINT pc_hd_check CHECK ((hd > 0)),
    CONSTRAINT pc_price_check CHECK ((price > (0)::numeric)),
    CONSTRAINT pc_ram_check CHECK ((ram > 0)),
    CONSTRAINT pc_speed_check CHECK ((speed > 0))
);


--
-- Name: pc_code_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE pc_code_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pc_code_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE pc_code_seq OWNED BY pc.code;


--
-- Name: printer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE printer (
    code integer NOT NULL,
    model text,
    color text,
    type text,
    price numeric,
    CONSTRAINT printer_price_check CHECK ((price > (0)::numeric))
);


--
-- Name: printer_code_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE printer_code_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_code_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE printer_code_seq OWNED BY printer.code;


--
-- Name: product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE product (
    maker text,
    model text NOT NULL,
    type text NOT NULL
);


--
-- Name: code; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY laptop ALTER COLUMN code SET DEFAULT nextval('laptop_code_seq'::regclass);


--
-- Name: code; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY pc ALTER COLUMN code SET DEFAULT nextval('pc_code_seq'::regclass);


--
-- Name: code; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY printer ALTER COLUMN code SET DEFAULT nextval('printer_code_seq'::regclass);


--
-- Data for Name: laptop; Type: TABLE DATA; Schema: public; Owner: -
--

COPY laptop (code, model, speed, ram, hd, screen, price) FROM stdin;
1	ROG GL552VX серый	2300	8000	1024	15.6	1095.11
2	Zenbook UX310UQ-FC518T серый	2400	4000	128	13.3	814.92
3	MacBook Pro Retina (MJLQ2RU/A) серый	2200	16000	256	15.4	2122.46
4	Legion Y520-15IKBN черный	2500	8000	128	15.6	1180.01
5	GP72 7RDX-489XRU LEOPARD черный	2500	16000	1024	17.3	1103.60
1	ROG GL552VX серый	2300	8000	1024	15.6	1095.11
2	Zenbook UX310UQ-FC518T серый	2400	4000	128	13.3	814.92
3	MacBook Pro Retina (MJLQ2RU/A) серый	2200	16000	256	15.4	2122.46
4	Legion Y520-15IKBN черный	2500	8000	128	15.6	1180.01
5	GP72 7RDX-489XRU LEOPARD черный	2500	16000	1024	17.3	1103.60
\.


--
-- Name: laptop_code_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('laptop_code_seq', 5, true);


--
-- Data for Name: pc; Type: TABLE DATA; Schema: public; Owner: -
--

COPY pc (code, model, speed, ram, hd, cd, price) FROM stdin;
1	Veriton S2710G [DT.VQEER.010]	3000	8000	1024	\N	480.39
3	Mars E171	3600	8000	1024	\N	531.34
4	Jupiter P124	3400	8192	1024	\N	1044.17
5	Veriton S2710G [DT.VQEER.012]	3500	4000	128	\N	280.02
6	Veriton S2710G [DT.VQEER.013]	2900	4000	128	24x	246.06
1	Veriton S2710G [DT.VQEER.010]	3000	8000	1024	\N	480.39
3	Mars E171	3600	8000	1024	\N	531.34
4	Jupiter P124	3400	8192	1024	\N	1044.17
5	Veriton S2710G [DT.VQEER.012]	3500	4000	128	\N	280.02
6	Veriton S2710G [DT.VQEER.013]	2900	4000	128	24x	246.06
\.


--
-- Name: pc_code_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('pc_code_seq', 6, true);


--
-- Data for Name: printer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY printer (code, model, color, type, price) FROM stdin;
5	SP 150W	\N	Laser	108.51
6	LaserJet Ultra M106w	\N	Laser	237.57
7	PIXMA iX6840	y	Jet	225.68
8	PIXMA iP8740	y	Jet	353.04
5	SP 150W	\N	Laser	108.51
6	LaserJet Ultra M106w	\N	Laser	237.57
7	PIXMA iX6840	y	Jet	225.68
8	PIXMA iP8740	y	Jet	353.04
\.


--
-- Name: printer_code_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('printer_code_seq', 8, true);


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY product (maker, model, type) FROM stdin;
Acer	Veriton S2710G [DT.VQEER.010]	PC
DEXP	Mars E171	PC
DEXP	Jupiter P124	PC
Acer	Veriton S2710G [DT.VQEER.012]	PC
Acer	Veriton S2710G [DT.VQEER.013]	PC
ASUS	ROG GL552VX серый	Laptop
ASUS	Zenbook UX310UQ-FC518T серый	Laptop
Apple	MacBook Pro Retina (MJLQ2RU/A) серый	Laptop
Lenovo	Legion Y520-15IKBN черный	Laptop
MSI	GP72 7RDX-489XRU LEOPARD черный	Laptop
Ricoh	SP 150W	Printer
HP	LaserJet Ultra M106w	Printer
Canon	PIXMA iX6840	Printer
Canon	PIXMA iP8740	Printer
\.


--
-- Name: product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_pkey PRIMARY KEY (model);


--
-- Name: laptop_model_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY laptop
    ADD CONSTRAINT laptop_model_fkey FOREIGN KEY (model) REFERENCES product(model);


--
-- Name: pc_model_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pc
    ADD CONSTRAINT pc_model_fkey FOREIGN KEY (model) REFERENCES product(model);


--
-- Name: printer_model_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY printer
    ADD CONSTRAINT printer_model_fkey FOREIGN KEY (model) REFERENCES product(model);


--
-- Name: public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

